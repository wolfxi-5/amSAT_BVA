#ifndef _warmup_h_INCLUDED
#define _warmup_h_INCLUDED

struct kissat;

void kissat_warmup (struct kissat *);

#endif
